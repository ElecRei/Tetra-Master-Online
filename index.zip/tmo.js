
/* 

    Power Levels

    0 = 0-10
    1 = 11-20
    2 = 21-30
    3 = 31-40
    4 = 41-50
    5 = 51-60
    6 =
    7 =
    8 =
    9 =
    A =
    B =
    C =
    D =
    E =
    F =



*/

$(document).ready(function(){
    
    var cardMat = document.getElementById("card_mat");
    
    var turnClicks = 1;
   
    for(i=0; i < 16; i++){
        
        $(cardMat).append("<div class='panel' id='" + i + "'></div>");
        console.log("Panel " + i + " created.");
        
    }
    
    var cardClick = 0;
    
    var lastPanel;
    
    $(".panel").click(function(){
        
        console.log(cardClick);
        
        if(cardClick < turnClicks){
        
            if($(this).hasClass("selected")){
                $(this).removeClass("selected");
            }
            else{
                $(this).addClass("selected");
            }
            
            cardClick++ 
            
            lastPanel = $(this).attr("id");
            
            console.log(lastPanel);
            
            $("#submit").removeAttr("disabled");
            
            console.log(cardClick);
        }
        else{
            alert("Your turn has ended!");
        }
    });
    
    $("#submit").click(function(){
        
        var selectedPanel = lastPanel;
        
        while(selectedPanel = lastPanel){
        
            selectedPanel = Math.random() * (15 - 0) + 0;
            
            console.log("New value is " + selectedPanel);
            
            if($(selectedPanel).hasClass("cpu_selected")){
                
               console.log("CPU already has this panel!");
               
            }
            else{
                $(this).addClass("panel.cpu_selected");
            }
        }
    });
    
    
});